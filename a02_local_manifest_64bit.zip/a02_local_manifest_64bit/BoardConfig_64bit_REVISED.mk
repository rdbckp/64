# Revised for 64-bit ARM (arm64)
# Copy to: device/samsung/a02/BoardConfig.mk

DEVICE_PATH := device/samsung/a02

# ============================================================
# Architecture — CHANGED TO 64-BIT
# ============================================================
TARGET_ARCH := arm64
TARGET_ARCH_VARIANT := armv8-a
TARGET_CPU_ABI := arm64-v8a
TARGET_CPU_ABI2 :=
TARGET_CPU_VARIANT := generic
TARGET_CPU_SMP := true
TARGET_BOARD_PLATFORM := mt6739
TARGET_BOOTLOADER_BOARD_NAME := a02

# 64-bit binder
TARGET_USES_64_BIT_BINDER := true

# ============================================================
# Kernel — UPDATED FOR 64-BIT BUILD
# ============================================================
TARGET_KERNEL_CONFIG := a02_defconfig
TARGET_KERNEL_SOURCE := kernel/samsung/a02
KERNEL_TARGET_ARCH := arm64

# arm64 kernel format:
BOARD_KERNEL_IMAGE_NAME := Image.gz

# Boot parameters (hardware-specific, unchanged):
BOARD_KERNEL_BASE := 0x40000000
BOARD_KERNEL_PAGESIZE := 2048
BOARD_RAMDISK_OFFSET := 0x05000000
BOARD_TAGS_OFFSET := 0x0e000000

# ============================================================
# Bootloader / Recovery (unchanged)
# ============================================================
TARGET_NO_BOOTLOADER := true
TARGET_NO_RADIOIMAGE := true
BOARD_HAS_NO_SELECT_BUTTON := true
BOARD_USES_RECOVERY_AS_BOOT := true
TARGET_RECOVERY_FSTAB := $(DEVICE_PATH)/rootdir/etc/fstab.mt6739
TARGET_RECOVERY_PIXEL_FORMAT := "BGRA_8888"

# ============================================================
# Partitions (hardware-specific sizes, unchanged)
# ============================================================
BOARD_SYSTEMIMAGE_PARTITION_SIZE := 2147483648
BOARD_VENDORIMAGE_PARTITION_SIZE := 536870912
BOARD_USERDATAIMAGE_PARTITION_SIZE := 11534336000
BOARD_BOOTIMAGE_PARTITION_SIZE := 33554432
BOARD_CACHEIMAGE_PARTITION_SIZE := 536870912
BOARD_FLASH_BLOCK_SIZE := 131072
TARGET_COPY_OUT_VENDOR := vendor
BOARD_VENDORIMAGE_FILE_SYSTEM_TYPE := ext4

# ============================================================
# Filesystem (unchanged)
# ============================================================
TARGET_USERIMAGES_USE_EXT4 := true
TARGET_USERIMAGES_USE_F2FS := true

# ============================================================
# SELinux (permissive for first-boot testing)
# ============================================================
BOARD_SEPOLICY_TEE_FLAVOR := msm
BOARD_SEPOLICY_DIRS += $(DEVICE_PATH)/sepolicy
BOARD_VENDOR_SEPOLICY_DIRS += $(DEVICE_PATH)/sepolicy
TARGET_SYSTEM_PROP += $(DEVICE_PATH)/system.prop

# ============================================================
# VNDK Configuration (64-bit CRITICAL)
# ============================================================
BOARD_VNDK_VERSION := 30

# ============================================================
# Device-specific
# ============================================================
USE_CAMERA_STUB := true

# ============================================================
# Include vendor-specific config
# ============================================================
-include vendor/samsung/a02/BoardConfigVendor.mk
